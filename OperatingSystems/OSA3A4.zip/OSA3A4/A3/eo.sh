echo "Enter 10 numbers:"
declare -a seen
count=0
even=0
odd=0
for i in {1..10}
do
    read num
    is_duplicate=0
    for val in "${seen[@]}"
    do
        if [ "$val" -eq "$num" ]; then
            is_duplicate=1
            break
        fi
    done
    if [ $is_duplicate -eq 1 ]; then
        echo "Duplicate number $num found — skipping..."
        continue
    fi
    seen+=("$num")
    if [ $((num % 2)) -eq 0 ]; then
        even=$((even + 1))
    else
        odd=$((odd + 1))
    fi
done
echo "Even numbers: $even"
echo "Odd numbers: $odd"
